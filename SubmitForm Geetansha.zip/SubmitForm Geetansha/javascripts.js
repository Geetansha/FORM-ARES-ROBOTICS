function submitForm(){
    if(document.getElementsByClassName("nameInput").value=="" ||
        document.getElementsByClassName("commentsInput").value=="" ||
        document.getElementsByClassName("aresInput").value=="" ||
        document.getElementsByClassName("emailInput").value=="" ||
        document.getElementsByClassName("roleInput").value==""  ){

    }
    else{
        alert("Submitted Successfully Thanks!!");
    }
}